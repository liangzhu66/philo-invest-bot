﻿echo # 哲学投资助手 > README.md

